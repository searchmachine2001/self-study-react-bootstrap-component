import React, { Component } from "react";
class Home extends Component {
  state = {};
  render() {
    return <h2>Home Componentss</h2>;
  }
}

export default Home;
