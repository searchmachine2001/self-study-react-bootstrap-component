import React, { Component } from "react";
class Alert extends Component {
  state = {};
  render() {
    return <h2>Alert Component</h2>;
  }
}

export default Alert;
