import React, { Component } from "react";
class Modal extends Component {
  state = {};
  render() {
    return <h2>Modal Component</h2>;
  }
}

export default Modal;
